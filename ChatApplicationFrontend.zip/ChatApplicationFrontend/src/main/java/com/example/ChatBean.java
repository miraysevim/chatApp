package com.example;

import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.file.UploadedFile;

import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


@Named("chatBean")
@SessionScoped
public class ChatBean implements Serializable {
    private String message;
    private List<Message> messages = new ArrayList<>();
    private byte[] image;
    private String imagePath;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<Message> getMessages() {
        return messages;
    }

    public void setMessages(List<Message> messages) {
        this.messages = messages;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    public void sendMessage() {
        // Mesajı şifreleme buraya eklemem lazım
        messages.add(new Message(message, imagePath));
        message = "";
        image = null;
        imagePath = null;
    }

    public void handleFileUpload(FileUploadEvent event) {
        UploadedFile uploadedFile = event.getFile();
        try {
            image = uploadedFile.getContent();
            imagePath = saveImage(image);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String saveImage(byte[] image) {
        // Resim kaydetme
        String filePath = "C:/path/to/uploadedImage.jpg";
        try (FileOutputStream fos = new FileOutputStream(new File(filePath))) {
            fos.write(image);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return filePath;
    }
}
